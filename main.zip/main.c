#include <stdio.h>
#include "graph.h"
#include "edges.h"
#include "forest-union-find.h"
#include "src/lista.h"

int main()
{
	int i = 0;
	int N, M;
	int U, V, W;
	scanf("%d %d", &N, &M);

	//Conjunto de Arestas ordernadas
	//para pensarmos enquanto uma lista;
	Edge * vetEdges = alocar_LerVetorArestas(M);
	ordenarArestas(vetEdges, M);
	int arestasConsumidas = 0;

	//Conjunto de Vértices, enquanto floresta
	InvertedTree ** floresta = (InvertedTree ** )malloc(sizeof(InvertedTree *) * N);
	int qtdFloresta = N;//diminui a cada Union
	for (int i=0; i<N; i++)
	{
		floresta[i] = makeSet(i);
	}
	ALGraph * grafo = criaGrafo(N);

	for (i=0; i < M; i++)
	{
		//printf("%d %d %d\n", vetEdges[i].u, vetEdges[i].v, vetEdges[i].w);
		if (UnionByRank(floresta[vetEdges[i].u], floresta[vetEdges[i].v]))
		{
			insereAresta(grafo, vetEdges[i].u, vetEdges[i].v, vetEdges[i].w);
		}
		else{

		}
	}
	imprimeGrafo(grafo);

	//liberaGrafo(grafo);
}


//void kruskal(Graph * )