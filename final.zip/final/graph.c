
#include "src/lista.h"

#include "src/lista.h"
#include "graph.h"
#include <stdlib.h>
#include <stdio.h>


TIPO criaTupla(int _vertice, int _valor)
{
	TIPO tupla;
	tupla.vertice = _vertice;
	
	tupla.valor = _valor;
	return tupla;
}

ALGraph *  criaGrafo(int vertices)
{   
    ALGraph * gp = (ALGraph * ) malloc(sizeof(ALGraph));
    gp->qtd_lista = vertices;
    gp->lista = (Lista ** ) malloc(sizeof(Lista *) * vertices); 
    gp->flag = (char *) calloc(sizeof(char), vertices);//flag
    for (int i=0; i<vertices; i++)
    {
        gp->lista[i] = iniciar_lista();
    }
    return gp;
}

void cleanFlag(ALGraph * gp)
{
    int i=0;
    if (!gp)
        return;
    for (i=0; i<(gp->qtd_lista); i++)
        gp->flag[i]=0;
}

void liberaGrafo(ALGraph * gp)
{
    for (int i=0; i<gp->qtd_lista; i++)
    {
        destruir_lista(gp->lista[i]);
    }
    free(gp->flag);
    free(gp->lista);
    free(gp);
}

int insereAresta(ALGraph * gp, int u, int v, int w)
{
    if (gp==NULL) //se diferente de null
        return -1;
    if (gp->lista == NULL)
        return -1;
    if (u>=gp->qtd_lista || v >= gp->qtd_lista)
        return -1;
    
    insercao_inicio_lista((gp->lista[u]), criaTupla(v, w));
    insercao_inicio_lista((gp->lista[v]), criaTupla(u, w));

    return 0;
}

void imprimeGrafo(ALGraph * gp)
{
	int i=0;
	No * aux;
	for (i=0; i<gp->qtd_lista; i++)
	{
		printf("%d\t", i);
		aux = gp->lista[i]->inicio;
		while(aux!=NULL)
		{
			printf("|%d %d|--->\t", aux->chave.vertice, aux->chave.valor);
			aux = aux->prox;
		}
		printf("\n");
	}
}
