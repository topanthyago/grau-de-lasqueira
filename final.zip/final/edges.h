#ifndef EDGES_INCLUDED
#define EDGES_INCLUDED

typedef int TIPO_EDGE;

typedef struct _edge{
	TIPO_EDGE w;
	int v;
	int u;
}Edge;
int cmpFuncEdgeSort(const void * a, const void * b);

void ordenarArestas(Edge * edge, int qtd);
void imprimeArestas(Edge * vet);
Edge * alocaVetorEdges(int qtd);

Edge * alocar_LerVetorArestas(int qtd);
void desalocaVetorEdges(Edge * ptr);

int cmpIntFuncSort(const void * a, const void * b);
void leVetorArestas(Edge * vet, int qtd);

void imprimeTabVetorArestas(Edge * vet, int qtd);








#endif // !EDGES_INCLUDED