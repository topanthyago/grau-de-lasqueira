#include "edges.h"
#include <stdio.h>
#include <stdlib.h>


Edge * alocaVetorEdges(int qtd)
{
	return (Edge *) calloc(sizeof(Edge), qtd);
}

void desalocaVetorEdges(Edge * edge)
{
	free(edge);
}

int cmpIntFuncSort(const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}

int cmpFuncEdgeSort(const void * a, const void * b)
{
	const Edge   * aa = (const Edge *) a;
	const Edge * bb = (const Edge *) b;
   return ( cmpIntFuncSort(&(aa->w), &(bb->w) ));
}


void leVetorArestas(Edge * edge, int qtd)
{
	if (!edge)
		return;
	int i=0;
	for (i=0; i<qtd; i++)
	{
		scanf("%d %d %d", &(edge[i].u),&(edge[i].v), &(edge[i].w));
	}
}
void imprimeArestas(Edge * vet)
{
	printf("%d\t%d\t%d\n", vet->u, vet->v, vet->w);
}


void imprimeTabVetorArestas(Edge * vet, int qtd)
{
	int i=0;
	
	printf("U\tV\tW\n");
	for (i=0; i<qtd; i++)
	{
		imprimeArestas(&vet[i]);
	}
}

Edge * alocar_LerVetorArestas(int qtd)
{
	Edge * vet = alocaVetorEdges(qtd);
	leVetorArestas(vet, qtd);
	return vet;
}

void ordenarArestas(Edge * edge, int qtd)
{
	qsort(edge, qtd, sizeof(Edge), cmpIntFuncSort);
}