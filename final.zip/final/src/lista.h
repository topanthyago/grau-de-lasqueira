#ifndef LISTA_INCLUDED
#define LISTA_INCLUDED



typedef struct tupla
{
	int vertice;
	int valor;
} TIPO;




typedef struct No{
	TIPO chave;
	struct No *prox;
} No;

typedef struct {
	No *inicio;
	int (*compar)(const void* a,const void* b); //funcao para comparar
	void (*swap)(void* a,void* b); //funcao troca
	void (*copy)(void* dest,void* origem);//copia
	void (*printer)( const void* obj);//imprime 
	void (*free_memory)( void* obj);
} Lista;






Lista * iniciar_lista();
int insercao_inicio_lista(Lista *p_l, TIPO valor);
int insercao_meio_lista(No *p, TIPO valor);
No* buscar_lista(Lista *p_l, TIPO ch_busca, No** pred);
int inserir_lista_ord(Lista *p_l, TIPO valor);
int remover_inicio_lista(Lista *p_l);
int remover_meio_lista(No* pred);
int remover_lista(Lista *p_l, TIPO chave_usu);
void imprimir_lista(Lista *p_l);
void destruir_lista(Lista *p_l);
int remover_kesimo_elemento_lista(Lista *p_l, int k);

#endif // !LISTA_INCLUDED