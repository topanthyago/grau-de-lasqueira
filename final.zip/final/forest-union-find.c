#include "graph.h"
#include "edges.h"

#include "forest-union-find.h"

InvertedTree * makeSet(int vertex)
{
	InvertedTree * tree = (InvertedTree *) malloc(sizeof(InvertedTree));
	tree->parent = tree;
	tree->rank = 0;
	tree->vertex = vertex;
	return tree;
}

InvertedTree * FindSet(InvertedTree * tree)
{
	while(tree->parent != tree)
		tree = tree->parent;
	return tree;
}


int UnionByRank(InvertedTree * x, InvertedTree * y)
{
	InvertedTree * rx;
	InvertedTree * ry;
	rx = FindSet(x);
	ry = FindSet(y);
	if (rx == ry)//ja sao da mesma arvore
		return 0;
	if (rx->rank > ry->rank)
		ry->parent = rx;
	else
	{
		rx->parent = ry;
		if (rx->rank == ry->rank)
			ry->rank++;
	}
	return 1;
}

/*
algorithm Kruskal(G) is
    F:= ∅
    for each v ∈ G.V do
        MAKE-SET(v)
    for each (u, v) in G.E ordered by weight(u, v), increasing do
        if FIND-SET(u) ≠ FIND-SET(v) then
            F:= F ∪ {(u, v)} ∪ {(v, u)}
            UNION(FIND-SET(u), FIND-SET(v))
    return F
*/
