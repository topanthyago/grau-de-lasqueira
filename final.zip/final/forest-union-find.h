#ifndef FOREST_UNION_FIND
#define FOREST_UNION_FIND



typedef struct _inverted_tree
{
	int vertex;
	int rank;
	struct _inverted_tree * parent;
}InvertedTree;



#include "graph.h"
#include "edges.h"

#include "forest-union-find.h"

InvertedTree * makeSet(int vertex);

InvertedTree * FindSet(InvertedTree * tree);


int UnionByRank(InvertedTree * x, InvertedTree * y);

/*
algorithm Kruskal(G) is
    F:= ∅
    for each v ∈ G.V do
        MAKE-SET(v)
    for each (u, v) in G.E ordered by weight(u, v), increasing do
        if FIND-SET(u) ≠ FIND-SET(v) then
            F:= F ∪ {(u, v)} ∪ {(v, u)}
            UNION(FIND-SET(u), FIND-SET(v))
    return F
*/



#endif // !FOREST_UNION_FIND